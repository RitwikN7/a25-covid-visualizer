README

Course: cs400
Semester: Spring 2020
Project name: a25-covid-visualizer
Team Members:
1. Drew Halverson, LEC 001, and dhalverson2@wisc.edu
2. Kritarth Vyas, LEC 001, and kbvyas@wisc.edu
3. Ritwik Prasad, LEC 001, and rprasad22@wisc.edu
4. Roshan Verma, LEC 002, and rverma9@wisc.edu
5. Timothy Bostanche, LEC 001, tbostanche@wisc.edu
 

Which team members were on same xteam together?
None

Other notes or comments to the grader:
